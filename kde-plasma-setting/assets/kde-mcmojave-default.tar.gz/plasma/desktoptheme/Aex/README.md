An OSX clone for Plasma.
